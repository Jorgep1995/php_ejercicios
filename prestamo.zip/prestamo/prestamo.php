<?php

class Prestamo {
    private $capital;
    private $tasaAnual;
    private $meses;
    private $tasaMensual;
    private $cuota;

    public function __construct($capital, $tasaAnual, $meses) {
        $this->capital = $capital;
        $this->tasaAnual = $tasaAnual;
        $this->meses = $meses;
        $this->tasaMensual = ($tasaAnual / 100) / 12;
        $this->calcularCuota();
    }

    private function calcularCuota() {
        $this->cuota = $this->capital *
            ($this->tasaMensual / (1 - pow(1 + $this->tasaMensual, -$this->meses)));
    }

    public function getCuota() {
        return $this->cuota;
    }

    public function generarTabla() {
        $saldo = $this->capital;
        $tabla = [];

        for ($i = 1; $i <= $this->meses; $i++) {
            $interes = $saldo * $this->tasaMensual;
            $capitalPagado = $this->cuota - $interes;
            $saldo -= $capitalPagado;

            $tabla[] = [
                'cuota' => $i,
                'monto' => round($this->cuota, 2),
                'interes' => round($interes, 2),
                'capital' => round($capitalPagado, 2),
                'saldo' => round(max($saldo, 0), 2)
            ];
        }

        return $tabla;
    }
}
