<?php
require_once 'Prestamo.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tabla de Amortización</title>
    <style>
        body { font-family: 'Avenir'; margin: 40px; }
        input { margin: 5px 0; padding: 5px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #333; padding: 8px; text-align: center; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>

<h2>Formulario de Préstamo</h2>

<form method="POST">
    <label>Monto de Capital:</label><br>
    <input type="number" name="capital" step="0.01" required><br>

    <label>Tasa de Interés Anual (%):</label><br>
    <input type="number" name="tasa" step="0.01" required><br>

    <label>Período en meses:</label><br>
    <input type="number" name="meses" required><br><br>

    <button type="submit">Generar Tabla</button>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $capital = $_POST['capital'];
    $tasa = $_POST['tasa'];
    $meses = $_POST['meses'];

    $prestamo = new Prestamo($capital, $tasa, $meses);
    $tabla = $prestamo->generarTabla();

    echo "<h2>Tabla de Amortización</h2>";
    echo "<table>";
    echo "<tr>
            <th>No Cuota</th>
            <th>Monto Cuota</th>
            <th>Interés</th>
            <th>Capital</th>
            <th>Saldo</th>
          </tr>";

    foreach ($tabla as $fila) {
        echo "<tr>
                <td>{$fila['cuota']}</td>
                <td>{$fila['monto']}</td>
                <td>{$fila['interes']}</td>
                <td>{$fila['capital']}</td>
                <td>{$fila['saldo']}</td>
              </tr>";
    }

    echo "</table>";
}
?>

</body>
</html>
