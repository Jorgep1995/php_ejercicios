<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iteración en PHP</title>
</head>
<body>

<h2>Ejemplo de Iteración</h2>

<form method="post">
    <label for="numero">Seleccione un número:</label>
    <select name="numero" id="numero" required>
        <?php
        // Combobox de 1 a 10
        for ($i = 1; $i <= 10; $i++) {
            echo "<option value='$i'>$i</option>";
        }
        ?>
    </select>

    <br><br>

    <label>
        <input type="checkbox" name="descendente">
        Iterar Inversamente (Descendente)
    </label>

    <br><br>

    <button type="submit">Mostrar</button>
</form>

<hr>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $numero = (int)$_POST["numero"];
    $esDescendente = isset($_POST["descendente"]);

    echo "<h3>Mostrando la Iteración</h3>";

    if ($esDescendente) {
        // Iteración descendente
        for ($i = $numero; $i >= 1; $i--) {
            echo "$i Hola Mundo<br>";
        }
    } else {
        // Iteración ascendente
        for ($i = 1; $i <= $numero; $i++) {
            echo "$i Hola Mundo<br>";
        }
    }
}
?>

</body>
</html>
