<?php
require_once "funciones.php";

$data = [
    "cliente" => $_POST['cliente'],
    "personas" => $_POST['personas'],
    "habitaciones" => $_POST['habitaciones'],
    "tipo_habitacion" => $_POST['tipo_habitacion'],
    "vista" => isset($_POST['vista']),
    "desayuno" => isset($_POST['desayuno']),
    "dias" => $_POST['dias']
];

$totales = calcularTotal($data);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Orden de Reserva</title>
</head>
<body>

<h2>Resumen de la Reserva</h2>

<table border="1" cellpadding="8">
    <tr><th>Cliente</th><td><?= $data['cliente'] ?></td></tr>
    <tr><th>Personas</th><td><?= $data['personas'] ?></td></tr>
    <tr><th>Habitaciones</th><td><?= $data['habitaciones'] ?></td></tr>
    <tr><th>Tipo</th><td><?= $data['tipo_habitacion'] ?></td></tr>
    <tr><th>Vista</th><td><?= $data['vista'] ? 'Sí' : 'No' ?></td></tr>
    <tr><th>Desayuno</th><td><?= $data['desayuno'] ? 'Sí' : 'No' ?></td></tr>
    <tr><th>Días</th><td><?= $data['dias'] ?></td></tr>
    <tr><th>Subtotal</th><td>$<?= number_format($totales['subtotal'],2) ?></td></tr>
    <tr><th>Impuesto Renta (15%)</th><td>$<?= number_format($totales['renta'],2) ?></td></tr>
    <tr><th>Impuesto Hotelero (18%)</th><td>$<?= number_format($totales['hotelero'],2) ?></td></tr>
    <tr><th>Total a Pagar</th><td><strong>$<?= number_format($totales['total'],2) ?></strong></td></tr>
</table>

<br>
<a href="index.php">Nueva Reserva</a>

</body>
</html>
