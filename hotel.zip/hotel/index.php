
<?php
require_once "funciones.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reserva Hotel</title>
</head>
<body>

<h2>Formulario de Reserva</h2>

<form action="procesar.php" method="POST">
    Cliente: <input type="text" name="cliente" required><br><br>

    Número de Personas: <input type="number" name="personas" min="1" required><br><br>

    Número de Habitaciones: <input type="number" name="habitaciones" min="1" required><br><br>

    Tipo de Habitación:
    <?php echo generarSelect("tipo_habitacion", tiposHabitacion()); ?>
    <br><br>

    Vista:
    <input type="checkbox" name="vista" value="1"> Con Vista<br><br>

    Desayuno:
    <input type="checkbox" name="desayuno" value="1"> Incluido<br><br>

    Días de Reserva:
    <input type="number" name="dias" min="1" required><br><br>

    <button type="submit">Reservar</button>
</form>

</body>
</html>
