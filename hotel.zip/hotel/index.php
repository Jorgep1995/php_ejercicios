<?php
require_once "clases/Reserva.php";
session_start();

if (!isset($_SESSION['reservas'])) {
    $_SESSION['reservas'] = [];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reservas de Hotel</title>
    <style>
        table { border-collapse: collapse; width: 65%; }
        th, td { border: 1px solid #afb7ff; padding: 8px; text-align: center; }
    </style>
</head>
<body>

<h2>Reserva de Hotel</h2>

<form action="procesar.php" method="POST">
    <input type="text" name="cliente" placeholder="Nombre del cliente" required><br><br>
    <select name="habitacion" required>
        <option value="Sencilla">Sencilla</option>
        <option value="Doble">Doble</option>
        <option value="Suite">Suite</option>
    </select><br><br>
    <input type="number" name="noches" placeholder="Noches" min="1" required><br><br>
    <button type="submit">Reservar</button>
</form>

<h2>Listado de Reservas</h2>

<table>
    <tr>
        <th>Cliente</th>
        <th>Habitación</th>
        <th>Noches</th>
        <th>Total ($)</th>
    </tr>

    <?php foreach ($_SESSION['reservas'] as $reserva): ?>
        <tr>
            <td><?= $reserva->getCliente() ?></td>
            <td><?= $reserva->getHabitacion() ?></td>
            <td><?= $reserva->getNoches() ?></td>
            <td><?= $reserva->getTotal() ?></td>
        </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
