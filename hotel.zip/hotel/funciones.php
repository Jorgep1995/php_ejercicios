<?php

// Arreglos maestros
function tiposHabitacion() {
    return [
        "Sencilla" => 40,
        "Doble" => 50,
        "Suite" => 70
    ];
}

// Generar select automático
function generarSelect($name, $opciones) {
    $html = "<select name='$name' required>";
    foreach ($opciones as $key => $value) {
        $html .= "<option value='$key'>$key</option>";
    }
    $html .= "</select>";
    return $html;
}

// Calcular precio
function calcularTotal($data) {
    $tipos = tiposHabitacion();

    $precioHabitacion = $tipos[$data['tipo_habitacion']];
    $vista = $data['vista'] ? 20 : 0;
    $desayuno = $data['desayuno'] ? 15 : 0;

    $subtotal = ($precioHabitacion + $vista + $desayuno) * $data['dias'] * $data['habitaciones'];

    $impuestoRenta = $subtotal * 0.15;
    $impuestoHotelero = $subtotal * 0.13;

    $total = $subtotal + $impuestoRenta + $impuestoHotelero;

    return [
        "subtotal" => $subtotal,
        "renta" => $impuestoRenta,
        "hotelero" => $impuestoHotelero,
        "total" => $total
    ];
}