<?php
function extraerCuentas($texto)
{
    // Separación del texto usando cualquier cosa que NO sea un número
    $partes = preg_split('/\D+/', $texto);

    $cuentas = [];

    foreach ($partes as $parte) {
        // Evitar cadenas vacías y filtramos por longitud mínima
        if (!empty($parte) && strlen($parte) >= 14) {
            $cuentas[] = $parte;
        }
    }

    return $cuentas;
}
