<?php
require_once "funciones.php";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Extractor de cuentas</title>
</head>
<body>

<h2>Extraer números de cuenta</h2>

<form method="post">
    <textarea name="texto" rows="6" cols="60" placeholder="Pega aquí el texto del docente"></textarea><br><br>
    <button type="submit">Extraer</button>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $texto = $_POST["texto"];
    $cuentas = extraerCuentas($texto);

    echo "<h3>Números de cuenta encontrados:</h3>";

    if (count($cuentas) > 0) {
        echo "<ul>";
        foreach ($cuentas as $cuenta) {
            echo "<li>$cuenta</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>No se encontraron números de cuenta.</p>";
    }
}
?>

</body>
</html>
